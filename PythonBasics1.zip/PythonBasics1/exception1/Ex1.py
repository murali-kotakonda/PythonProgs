list = [10, 20, 30,40]
print(list[0])
print(list[7]) # trying to access 8th element but list has 3 elements
print(list[2])
print("Bye")

#in this case python creates IndexError


