age  =  int(input("enter age") )
print("after concerting age= ",age)
print("bye")

# ValueError