# Python program to handle simple runtime error 
#https://www.geeksforgeeks.org/try-except-python/
a = [1, 2, 3] 
try:  
    print("Second element = {}".format(a[1])) 
  
    # Throws error since there are only 3 elements in array 
    print("Fourth element = {}".format(a[3]))  
  
except IndexError: 
    print("An error occurred")
else:
    print("No exception")
finally:
    print("in final")