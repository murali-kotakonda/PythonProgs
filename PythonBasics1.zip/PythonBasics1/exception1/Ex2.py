x= 50
y =0

divRes = x/y
print("result = ", divRes)
print("bye")

#python is creating ZeroDivisionError: division by zero