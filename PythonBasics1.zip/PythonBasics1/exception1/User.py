'''
Created on Aug 6, 2018

@author: i335484
'''

if __name__ == '__main__':
    pass

print("Hello")