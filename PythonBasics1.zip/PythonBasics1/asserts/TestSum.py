def div(n1,n2):
    print(n2)
    assert n2!=0 , " n2 value cannot be zero"
    return n1/n2;

print(div(10,20))
print(div(10,0))

