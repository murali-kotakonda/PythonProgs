def sum(n1,n2):
    return n1-n2;


s1 = sum(10, 20)
assert s1<0 ,"invalid sum"
print("sum validation success")
