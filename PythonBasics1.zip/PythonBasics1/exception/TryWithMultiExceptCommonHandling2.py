arr = [1, 2, 3, 4, 7]
def square():
    intNum = 0
    try:
        intNum = int("hgh");
        print(arr[2])
        print(1/1)
    except Exception:
            print("error invalid usage of arguments...")
    else:
        print("No Exception.......")
    
    print("bye ")
square()






