a = [1, 2, 3] 
print(a[1]) 
print(a[3]) 
    
    
n1 = 5
n2= 0

print(n1/n2)

print("bye bye")