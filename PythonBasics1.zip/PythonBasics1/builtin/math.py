print(abs(-78.78))

print(abs(78+6j))


print(round(67.74866666,4))
print(round(67.54866666,2))
print(round(67.44866666))


print(max(12,89,0,8,67))
print(max([12,89,0,8,67]))
print(max((12,89,0,8,67)))

print(min(12,89,0,8,67))
print(min([12,89,0,8,67]))
print(min((12,89,0,8,67)))

print(sum((12,89,0,8,67)))
print(sum([12,89,0,8,67]))
print(sum((1,2,3,4),1))



print(pow(8,3))

"sort numbers"
data = (34,1,6,78,90)
print(sorted(data))

"sort numbers in decending order"
print(sorted(data,reverse=True))



data = ("HELLO","APPLE","ZEBRA")
print(sorted(data))
#"SORT strings in desc order"
print(sorted(data,reverse=True))




