print("Hello")

#Declare a variable and assign the values

"""
datatype : defines the type of data.
in python we dont need to specify the datatype.
python will identify the datatype.

what are the primitive datatypes supported?
ans)
int
float
string
boolean
complex

variable : is the reference name that holds the data/value.
every variable is associated to the data type .

"""
#How to create a variable for diff datatypes?

x = 90 # create a varible x
y = 90.123

z = 'hello'

a= "Hi"

b ="""
hello im krishna
I teach python and selenium.
Have a great day
"""

c = True
d = False

e= 5+ 4j # contains real num and imaginary value


print("*******************print in one line**************************")
print(x, y ,z , a , b , c, d, e )

#how to print all the varibles in a new line using print function
print("*******************print in new line**************************")
print(x, y ,z , a , b , c, d, e, sep="#" )





