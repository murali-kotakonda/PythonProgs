#Print the data types


#snfsjgfbnmdabgmdsabgdbgdbgdsbgdbgdang,danvm,mzmbvbdznmdvnbd
"""

How to write comments in python?
ans)
1. for single line comment use [ # ]
2. for multi line comments use  [ """    """ ]


How to get the datatype for a variable?
ans) use type() function


"""


x = 90 # create a varible x
print(x, type(x))

y = 90.123
print(y, type(y))

z = 'hello'
print(z , type(z))

d = False
print(d , type(d))


e= 5+ 4j # contains real num and imaginary value
print(e , type(e))


