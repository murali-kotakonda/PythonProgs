# LOOPS :

# init value = 0 , max value is value-1 , incremnet is 1
for i in range(10):
    print(i)

print("##############################")

# prints from 0 to 9
    

# init value =1 , max value =10 , increment 1    
for i in range(1, 11):
    print(i)
    
maxValue = int(input("enter max value for even nums to print"))
for j in range(2, maxValue + 1, 2):
      print(j)

count = 1;
while count <= 10:
    print(count)
    count += 1
    
print("END OF CODE6")

#INDENT IF, IF ELSE , IF, ELSEIF, FOR , WHILE 


#while loop
x=int(input("enter the no to print"))
y=1
while (y<x):
    if y/2==1:
        print(y)
    y = y+1      
else:
    print("end")


