# input() method returns a string


#take input
name = input("enter name")
print("your name = " , name, type(name))

#take int as input
id = int(input("enter id"))
print("your id = = " , id , type(id))



#take float as input
roi = float(input("enter roi"))
print("your roi = = " , roi , type(roi))



print("enter your name")
name = input()
print(name)

print("enter your sal")
sal = float(input())
print(sal)

# sum of two numbers
num1 = int(input("enter num1 "))
num2 = int(input("enter num2 "))
ResultSum = num1 + num2
print(ResultSum)

