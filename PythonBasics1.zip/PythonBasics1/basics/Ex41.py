#Opeartors
n1 = 30
n2= 20

sum  = n1 + n2
print("sum  of {} and {} is {} ".format(n1,n2,sum))

sub  = n1 - n2
print("sub  of {} and {} is {} ".format(n1,n2,sub))


mul  = n1 *  n2
print("mul  of {} and {} is {} ".format(n1,n2,mul))


div1  = n1 / n2
print("div  of {} and {} is {} ".format(n1,n2,div1))


div2  = n1 // n2
print("div2  of {} and {} is {} ".format(n1,n2,div2))


rem  = n1 % n2
print("rem  of {} and {} is {} ".format(n1,n2,rem))

