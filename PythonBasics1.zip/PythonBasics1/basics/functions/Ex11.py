"""

function that takes name as input and returns with Mr.Mrs
"""

#WRITE THE FUNCTION
def greet(name):
    v = "Mr/Mrs "+ name
    return  v


#call the function

d1 = greet("kumar")
print(d1)

d1 = greet("raj")
print(d1)

