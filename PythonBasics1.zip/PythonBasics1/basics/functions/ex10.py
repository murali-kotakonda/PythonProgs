"""


"""
#code for writing the function
def getData():
    x  = "Hello"
    return x
#x is local varibles

#call the function

v1 = getData()
print(v1)

v2 = getData()
print(v2)