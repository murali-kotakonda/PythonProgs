"""

function that takes two nums as input and perform the sum
"""

#WRITE THE FUNCTION

def sum(x,y):
    res = x+y
    return  res


#call the function
v1 = sum(10,30)
print(v1)


v2 = sum(80,20)
print(v2)

