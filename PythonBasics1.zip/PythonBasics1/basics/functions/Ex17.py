"""
var arg function: a fuction that takes any umber of arguments.
"""

#WRITE THE FUNCTION
def show(*data):
    print(data)
#show cfuntion can be called by passing any number of values

#call the function
show(1,2)
show(1,2,24,2,5,21,36,25,343,7,25,7,25,43,3256,47)




