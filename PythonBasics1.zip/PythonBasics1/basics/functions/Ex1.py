


"""
Write a function that prints welcome msg
and call the function

"""
 



#how to write function
def myfunction():
    print("hi")
    print("welcome")
    print("bye")


#how to call the function
myfunction()
myfunction()
