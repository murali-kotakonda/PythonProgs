#function with default args

def printMsg(msg="Mumbai"): # passing msg is not mandatory
    print(msg)


#call function
printMsg(10)
printMsg("bangalore")
printMsg()