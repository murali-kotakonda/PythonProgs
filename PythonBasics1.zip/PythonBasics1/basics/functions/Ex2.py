"""
write a function that takes one input argument and prints the same
call the function

"""

#how to write function
def f2(name):
    print("your input =" , name)
#data is the input argument


#how to call the function
f2("user1")
f2(1234)
f2(5+5j)
f2(1313.1313)
f2(True)