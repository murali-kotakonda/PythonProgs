#function with default args

def f1(id,name,age):
    print("Id=" , id)
    print("name=", name)
    print("age", age)
    print("**************************")


#call the function

f1(100,"kumar",45)

f1(age=90, name="raj", id= 78)

f1(name="ramesh", id= 900 , age= 45)


