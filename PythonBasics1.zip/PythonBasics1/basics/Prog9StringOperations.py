from builtins import str
myName = "muralidhar, Reddy,kumar"



print("2 = ",name[1])
# name[3] ='h'  = not possible
print(myName.capitalize())
print(myName.casefold())





# extract substring
str ="Hellouser! welcome to python! programmming is fun"
print(str[0])
print(str[0:3])# substring from 0 position to 2nd position
print(str[:4]) # extract 1st n chars
print(str[10:25])# from 10th till 24


print(str[-1]) # last but one  n
print(str[-3]) # last but three f

print(str[:-3]) # from 0 position till (size-3) position
print(str[-3:]) # last three chras
print(str[2:-3]) # from 2nd till last but 3

