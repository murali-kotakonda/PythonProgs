"""
1.
Input = 5
O/p :
1
1 2
1 2 3
1 2 3 4
1 2 3 4 5



1
22
333
4444
55555



2.Input : 5
o/p:
5
5 4
5 4  3
5 4 3 2
5 4 3 2 1

3. Take inputL 10
print numbers from 1 to 10
print all evens from 1 to 10
print all odd from 2 to 10
Find the factorial of 5
sum of nums till 10
Print multiplication table

4. Input hw many nums and what are the nums:
and print sum , big , small nums

5.Help teacher to find first rank for input
student name + sub1 + sub2 + sub3
How many students  = size


6.input 3:

O/p:
1 2 3
4 5 6
7 8 9

and  print diagonal
1 5 9
3 5 7




without size:
-------------------------------------------------------

7.take nums as input
and perform sum
if the sum reaches 100 , stop and print final sum




4.take nums as input  and if we enter 999 thats end of input
and print sum , big , small nums




"""