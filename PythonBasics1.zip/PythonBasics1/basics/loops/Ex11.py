"""
Take size as input and print the numbers from 1 till the input size
"""

size = int(input("enter the size"))

for i in range(1,size+1):
    print(i)