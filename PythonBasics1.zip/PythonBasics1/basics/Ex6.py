#Opeartions + , - , * , / %

a = int(input("enter num1"))
b = int(input("enter num2"))

c= a+b
print("sum = ", c)

c= a-b
print("sub = ", c)

c= a*b
print("mul = ", c)

c= a/b
print("div using /  = ", c)

c= a//b
print("div using // = ", c)



c= a%b
print("remainder = ", c)

c= a**b
print("exponential, [power] = ", c)