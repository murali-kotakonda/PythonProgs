# varibalename = value
 
# declare int varibale and assign value
num = 20 
num = 31
# declare float
sal = 23000.34
# declare string
name = "muralidhar"
x='g'
print(type(x))


z= complex(5,8)
print(z.real)
print(z.imag)

#binary type
bin=0B1010
print("binary = ",bin, type(bin))

#Hexa decimal to the base of 16
f=0XFF
print(f)

print(hex(255))

#Octal
f=0O10
print(f)

print(oct(8)) #to octal

print(10) #static int
print(20.456) # static float
print(num,sal,name) #

# single quote
print('hi')

# double quote
print("hi")

# triple quote
# trest
print("""Hello user
test
user1
user2
""")

"""
hello
this is my prog



khgj

hhhv

"""
print("my comment")
