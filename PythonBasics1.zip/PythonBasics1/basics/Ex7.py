# take two numbers as inout and perform add, mul, sub , div
n1 = float(input("enter num1"))
n2 = float(input("enter num2"))

sum  = n1 + n2
print("sum  = ", sum)


sub  = n1 - n2
print("sub  = ", sub)


mul  = n1 *  n2
print("mul  = ", mul)


div1  = n1 / n2
print("div1  = ", div1)


div2  = n1 // n2
print("div2  = ", div2)


rem  = n1 % n2
print("rem  = ", rem)

