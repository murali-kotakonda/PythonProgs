str1 = 'The quick brown fox jumps over the lazy dog.'
print()
print(str1.count("fox"))
print()