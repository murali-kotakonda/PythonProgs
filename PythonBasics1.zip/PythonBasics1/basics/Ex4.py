#Opeartors
# perform arthmetic operations on two variables

n1 = 30
n2= 20

sum  = n1 + n2
print("sum  = ", sum)


sub  = n1 - n2
print("sub  = ", sub)


mul  = n1 *  n2
print("mul  = ", mul)


div1  = n1 / n2
print("div1  = ", div1)


div2  = n1 // n2
print("div2  = ", div2)


rem  = n1 % n2
print("rem  = ", rem)


z = f
print(z,f)

print(z is f) # identity operator ; both are points to same obj

a = 25
b = 10

e = 10 & 12 #prints8  compares binaries  1010 1100    -->1000 = 8 bits wise comparision
e = 10 | 12 # 1010  1100  -> 1110 prints 14
e = 10 >> 2  # converts 1010 to 10
print(e) # 2
e = 10 << 2   # converts 1010 to 101000
print(e) #40

# Examples of Bitwise operators
a = 10
b = 4

# Print bitwise AND operation
print(a & b)

# Print bitwise OR operation
print(a | b)

# Print bitwise NOT operation
print(~a)

# print bitwise XOR operation
print(a ^ b)

# print bitwise right shift operation
print(a >> 2)

# print bitwise left shift operation
print(a << 2)


"""

assignment:
---------------
 
sum of 30 and 20 is 50
sub of 30 and 20 is  10
mul  of 30 and 20 is  600
div1  of 30 and 20 is  1.5
div2  of 30 and 20 is  1
rem   of 30 and 20 is  10



"""
