
"""
Req:
create a folder 
"""
import os

os.mkdir("test5")