# take all cities as input and finally display
# take cities as input and avoid duplicates
