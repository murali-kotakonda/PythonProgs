def add(x,y):
    print(x+y)

def add(x,y,z,a):
    print(x+y+z)


add(5,6,8,1)
add(5,6)