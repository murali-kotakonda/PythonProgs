def add(x,y):
    z= x+y
    print(z)

add(5,6)