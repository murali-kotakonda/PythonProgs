
"""
 functions ----> reuse the code
 code :- reused in diff places of ur project
 solution: write code once and reuse any no of times  ==> FUNTIONS


SYNATX
 1. def keyword to write a function
 2. after def specify funtion name
 3. function can take any input and can return only one output
        
# use the indentation for the funtion body

"""




# 6. function for pass by value and change value
def changeNum(x): # n is formal argument n = num3
    y =30

num3= 62
changeNum(num3)  # num3 is actual argument
print(num3)    # 62

x= 20
changeNum(x)
print(x)


