def printMsg(msg):
    print("data ==", msg)
    
printMsg("hello")
printMsg(123)
printMsg(54.14)
