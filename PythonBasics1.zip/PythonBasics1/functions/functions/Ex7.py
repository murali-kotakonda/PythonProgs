def change(y):
    y=90
    

x=56
print(x)
change(x)
print(x)