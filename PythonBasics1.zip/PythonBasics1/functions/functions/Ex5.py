def div(n1,n2):
    if n2==0:
        return "denomonator cannt be zero"
    return n1/n2

print(div(12,2))
print(div(12,0))
        