def printInfo(id,name="NA"):
    print("id=", id)
    print("NAME ==", name)
    
    
printInfo(1000,"user1")
printInfo(1000)
