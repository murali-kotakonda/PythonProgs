def printHi():
    print("Hello")
    
printHi()