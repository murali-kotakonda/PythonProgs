
"""

[8:44 PM] Kotakonda, Muralidhar Reddy
    1.big of 2 no
​[8:45 PM] Kotakonda, Muralidhar Reddy
    3.small of 2 nos
​[8:45 PM] Kotakonda, Muralidhar Reddy
    big od 3 nos
​[8:45 PM] Kotakonda, Muralidhar Reddy
    small of 3 nos
​[8:45 PM] Kotakonda, Muralidhar Reddy
    factorial of number
​[8:45 PM] Kotakonda, Muralidhar Reddy
    isEven
​[8:45 PM] Kotakonda, Muralidhar Reddy
    isOdd



"""