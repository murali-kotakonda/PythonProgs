
myAddr = Address