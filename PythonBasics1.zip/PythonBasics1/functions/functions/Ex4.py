def getMsg(name):
    return "Mr." + name

res = getMsg("user1")
print(res)
print(getMsg("user2"))
    
    
