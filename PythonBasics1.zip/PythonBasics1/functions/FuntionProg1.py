def f1():
    print("hello")
    print("welcome")
    print("bye")

print("hi")
f1()
f1()