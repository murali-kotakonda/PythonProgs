#generator is a funtn
#generator conbtains more than one yield statements.
