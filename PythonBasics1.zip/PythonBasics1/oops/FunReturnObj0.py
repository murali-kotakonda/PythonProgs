class person:
    id=None
    name=None
    age=None

p1=person()
p2=person()
p3=person()

p1.id=1
p1.name='raju'
p1.age=23

p2.id=2
p2.name='kiran'
p2.age=25

p3.id=3
p3.name='ripesh'
p3.age=26

print(p1.id)
print(p1.name)
print(p1.age)

print(p2.id)
print(p2.name)
print(p2.age)

print(p3.id)
print(p3.name)
print(p3.age)





