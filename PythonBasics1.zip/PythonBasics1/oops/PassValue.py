def change(y):
    y= 90


x=80
print("***************BEFORE***********************")
print(x)

change(x)

print("***************AFTER***********************")
print(x)


x= 90

y =x
print(x , y)

y =100
print(x , y)



