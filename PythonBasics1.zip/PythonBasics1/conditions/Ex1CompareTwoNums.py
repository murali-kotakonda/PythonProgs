"""
write a program  to take two nums as input check if two nums are equal or not
"""
n1 = int(input("enter num1 "))
n2 = int(input("enter num2 "))


if n1==n2 :
    print("if started")
    print("nums are equal")
else:
    print("else started")
    print("nums are not equal")


"""
here if is a block
else is a block

every block should have : at the end 
the block code should always start with the TAB space.

python is very strong in indentation.
other languages uses {} for block
python uses TAB space for block.



"""

