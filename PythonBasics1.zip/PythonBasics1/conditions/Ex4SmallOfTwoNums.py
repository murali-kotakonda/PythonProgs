"""
find small of two numbers
"""
n1 =  int(input("enter num1 "))
n2 =  int(input("enter num2 "))


if n1 < n2 :
    print("if started")
    print("small =" , n1)
else:
    print("else started")
    print("small =", n2)

