x = int(input("enter no"))          
y = int(input("enter no"))


if x==y:
    print("x and y are same")
    print("bye")
else:
    print("x and y are not equal")
    print("bye")

print("End of code")
    


x=int(x)