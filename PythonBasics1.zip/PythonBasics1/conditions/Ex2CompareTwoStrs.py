"""
write a program  to take two strings as input check if two nums are equal or not
"""
n1 =  input("enter str1 ")
n2 =  input("enter str2 ")


if n1==n2 :
    print("if started")
    print("strings are equal")
else:
    print("else started")
    print("strings are not equal")

