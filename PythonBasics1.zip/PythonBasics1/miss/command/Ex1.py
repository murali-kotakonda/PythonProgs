#Write a python program to call an external command in Python.
from subprocess import call
call(["ls", "-l"])