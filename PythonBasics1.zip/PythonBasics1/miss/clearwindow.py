import os
import time
# for windows
# os.system('cls')
os.system("dir")
time.sleep(2)
# Ubuntu version 10.10
os.system('cls')



import subprocess
# file and directory listing
returned_text = subprocess.check_output("dir", shell=True, universal_newlines=True)
print("dir command to list file and directory")
print(returned_text)