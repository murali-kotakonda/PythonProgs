
"""

\Z - Matches if the specified characters are at the end of a string.

Expression

Python\Z

I like Python	1 match
I like Python Programming	No match
Python is fun.	No match

"""