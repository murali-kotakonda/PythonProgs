print("****************read****************")
f3 = open("user.txt", "r")
x= f3.read()

print(type(x)) #print all
print(x)

f3.close()


