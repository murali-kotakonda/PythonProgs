import os
print()
print(os.path.basename('/users/system1/student1/homework-1.py'))
print()