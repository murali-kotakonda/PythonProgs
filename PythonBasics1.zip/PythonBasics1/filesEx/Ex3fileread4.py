print("****************read line by line****************")
f3 = open("user.txt", "r")
print(f3.readline()) #print the entire  1st line
print(f3.readline()) #print the entire  2nd line
print(f3.readline())
f3.close()