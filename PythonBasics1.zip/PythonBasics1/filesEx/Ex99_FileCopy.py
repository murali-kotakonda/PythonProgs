import os
from shutil import copyfile
from shutil import copy

copyfile("user.txt", "user1.txt")
#copy('file1.txt','test2')


