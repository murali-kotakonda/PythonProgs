#iteratively print every line
print("****************read iteratively****************")
f3 = open("user.txt", "r")
for line in f3:
    print( line)

