'''
Modules:
------------------------------

create packages:

1.modules
   Module1.py
   Module2.py
   Ex1.py
   Ex2.py
   Ex3.py
   Ex4.py
2.modulesext
  Module3.py
  Module4.py


'''
def display(name):
    print("printing display from Module1",name)

class Person:
    id=None
    name= None


def display1(name):
    print("printing display1 from Module1",name)

