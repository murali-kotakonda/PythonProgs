#relative imports

"""
from .. import FuntionProg2
FuntionProg2.f2("aaaa")



"""


from . import Module1
Module1.display("sfdsf")

#from ..filters import equalizer
