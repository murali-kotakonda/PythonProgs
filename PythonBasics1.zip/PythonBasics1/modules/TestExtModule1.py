from PythonBasics1.modulesext import *
# depends on __all__ = ["Module4"]


Module4.m5("jhjhj")

