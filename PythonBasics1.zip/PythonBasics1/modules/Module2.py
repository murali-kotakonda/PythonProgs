'''
Created on Jul 10, 2018

@author: I335484
'''
def display(name1):
    print("printing display from Module2",name1)
    
def performSum(n1, n2):
    if n1 < 0 or n2 < 0:
        return 0
    return n1 + n2


user="ram"

mylist =['user1','user2','user3']
myTuple =('user1','user2','user3')
