import  Module2



Module2.user ="shyam"
print(Module2.user)


Module2.mylist[0] = 'user5'
print(Module2.mylist)

