
def m5(name):
    print("printing m5 from Module3",name)

class Student:
    id=None
    name= None


def m6(name):
    print("printing m6 from Module3",name)

