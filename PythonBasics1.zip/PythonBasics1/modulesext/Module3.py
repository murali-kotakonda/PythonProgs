
def m3(name):
    print("printing m3 from Module3",name)

class Student:
    id=None
    name= None


def m4(name):
    print("printing m4 from Module3",name)

