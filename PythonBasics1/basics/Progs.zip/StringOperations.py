from builtins import str
myName = "Muralidhar,Reddy,kumar"

print(myName.capitalize())
print(myName.casefold())
print(myName.endswith("kumar")) 
print(myName.find("Reddy"))  # <0   >=0
print(myName.index("Mur"))

print(len(myName)) # find length
print(myName.split(","))  # returns the string array

# + ----> append
name1 = "bangalore"
name2="india"
print(name1+name2)


#* ---->on a string , repear string for a given no of time
print(name2 * 3)


#Frequency "india"
str3 = "I love India!! India is my country"
print(str3.count("India")) # for entire string
print(str3.count("India",10)) # for starting from  10 till end
print(str3.count("India",0 ,15)) # for starting from  10 till 15

#sub strings
str4="Hello User!Welcome to Python"
# for +ve get sub sring from the begining
print(str4[0]) # single character
print(str4[0:5]) # strating from 0 to 5
print(str4[:4]) # starting char index is  0


# for a negative value, consider from tailing end
print(str4[-1]) # last char
print(str4[-3]) # last but 3rd char
print(str4[2:-3]) # from 2nd till last but 3


