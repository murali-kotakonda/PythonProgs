# int , string float
#  == 
# !=
#  >
#  >=
# <
# <=

num1 = 40  # ; is optional
num2 = 40;

# if 
if num1 == num2 :
    print("num1 and num2 are equal")

userType = "user"
# if else
if userType == "admin":
    print("Allowed")
else :
    print("Not Allowed")

# if elseif
bank = "hdfc"

if bank == 'icici':
    print("Intrest = 10%")
elif bank == 'citi':
    print("Intrest = 12%")
elif bank == 'sbi':
    print("Intrest = 9%")
else :
    print("Bnak not found")
    
