# single quote
print('hi')


# double quote
print("hi")


# triple quote
# trest
print("""Hello user
test
user1
user2
""")

 
"""
hello
this is my prog



khgj

hhhv

"""
print("my comment")
