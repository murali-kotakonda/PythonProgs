# input two string , sum  not concactination
num1 = "20.32"
num2 = "21.45"


# convert string, float to float  -->float()
n1 = float(num1)
n2 = float(num2)
print(n1+n2)

# input two string , sum  not concactination
num3 = "20.56"
num4 = 51

# convert string, int to float  -->int()
n1 = float(num3)  # convert string to float
n2 = float(num4)  # convert float to float

print(n1+n2)


