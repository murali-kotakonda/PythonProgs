# TAKE INT AS INPUTS CONTINUOSLY , AND PERFORM SUM , IF THE SUM  >= 50 stop and print
sum= 0
 
while sum <50:
    i = int(input('enter number'))
    sum= sum+i;
    print("current sum =",sum)
 
print(sum)


# TAKE INT AS INPUTS CONTINUOSLY , AND PERFORM SUM , IF THE SUM  >= 50 stop and print , if negative num --> dont sum 
sum= 0
while sum <50:
    i = int(input('enter number'))
    if i<0 :
        continue # take you to next iternation  by stopping curren iteration
    sum= sum+i;
    print("current sum =",sum)
 
print(sum)


# TAKE INT AS INPUTS CONTINUOSLY , AND PERFORM SUM , IF THE SUM  >= 50 stop and print , if negative num --> stop algorithm , and  display current sum 
sum= 0
while sum <50:
    i = int(input('enter number'))
    if i<0 :
        break # stop all iterations and come out of the loop
    sum= sum+i;
    print("current sum =",sum)

print(sum)
