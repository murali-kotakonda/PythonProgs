# varibalename = value
 
# declare int varibale and assign value
num = 20 

num = 31

# declare float
sal = 23000.34

# declare string
name = "muralidhar"


print(10) #static int
print(20.456) # static float
print(num,sal,name) # 