# input() method returns a string
 
print("enter your name")
name = input()
print(name)

print("enter your sal")
sal = float(input())
print(sal)

# sum of two numbers
num1 = int(input("enter num1 "))
num2 = int(input("enter num2 "))
ResultSum = num1 + num2
print(ResultSum)

