# functions ----> reuse the code   

# 1. defining a function with no input and no output
def printHi():
    print("Hello") 

    
# Calling function
printHi()


# 2.  defining a function with input and no output
def printMsg(msg):
    print(msg)


# Calling function    
printMsg("Hi welcome")
name = "Murali"
printMsg(name)


# 3.  defining a function with input  and no output ; and input has a default value if not passed
def printMsgWithDefault(msg='Mumbai'):  # specify deafult value if the argument is not passed
    print(msg)


# Calling function    
printMsgWithDefault("Bangalore")  # BANGALORE
printMsgWithDefault()  # Mumbai


# 4. method taking string as input and string as output
def getMsg(inputMsg):
    return "your data = " + inputMsg


# Calling function    
myData = getMsg("Mythri Technologies")  # capture the optput form the method getMsg
print(myData)


# 5. method taking two integers as  input and  return the sum as output , if numbers ae negative then return -1
def performSum(n1, n2):
    if n1 < 0 or n2 < 0:
        return 0
    return n1 + n2


# Calling functions
sumResult1 = performSum(10, 20)  
sumResult2 = performSum(20, 50)
sumResult3 = performSum(-20, -50)
print(sumResult1)         
print(sumResult2)
print(sumResult3)


# 6. function for pass by value and change value
def changeNum(x): # n is formal argument n = num3
    y =30


num3= 62
changeNum(num3)  # num3 is actual argument
print(num3)    # 62




x= 20
changeNum(x)  
print(x)
