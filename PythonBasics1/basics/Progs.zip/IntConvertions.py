# input two string , sum  not concactination
num1 = "20"
num2 = "31"

# convert string, float to int  -->int()
n1 = int(num1)
n2 = int(num2)
print(n1+n2)


# input two string , sum  not concactination
num3 = "20"
num4 = 51.56

# convert string, float to int  -->int()
n1 = int(num3)  # convert string to int
n2 = int(num4)  # convert float to int

print(n1+n2)









