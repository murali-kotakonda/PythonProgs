name = "muralidhar "
print(name)

# string collection of char, str = char array
# index from 0 to size-1
print(name[0])  # print 1st cahr
print(name[0:3])  # substring

name1 = "kumar"

# concatenation of strings
name3 = name + name1 

x = 10
y = 20
# addition of two nums
z = x + y

# to identify   type 
print(type(z))   
print(type(name3))

print(name3, z)

print(name3 + str(z))  # contactenation  , convert int to str 
# str(z)  -- to convert int , float to string

c = 5+6j
print(c)