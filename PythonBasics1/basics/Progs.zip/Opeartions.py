# + , - * % , /
a = 20
b = 10
c = a * b 
print("sum is ", c)

c = a - b 
print("sub is ", c)

c = a / b 
print("div is ", c)

c = a % b 
print("rem is ", c)
